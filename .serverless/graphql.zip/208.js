"use strict";exports.id=208,exports.ids=[208],exports.modules={8357:(h,s,r)=>{r.d(s,{b:()=>d});const d="4.7.5"},7208:(h,s,r)=>{r.d(s,{ApolloServerPluginLandingPageLocalDefault:()=>y,ApolloServerPluginLandingPageProductionDefault:()=>S});function d(n){return JSON.stringify(n).replace("<","\\u003c").replace(">","\\u003e").replace("&","\\u0026").replace("'","\\u0027")}const b=(n,e,t,o)=>{const a={displayOptions:{},persistExplorerState:!1,runTelemetry:!0,...typeof e.embed=="boolean"?{}:e.embed},i={graphRef:e.graphRef,target:"#embeddableExplorer",initialState:{..."document"in e||"headers"in e||"variables"in e?{document:e.document,headers:e.headers,variables:e.variables}:{},..."collectionId"in e?{collectionId:e.collectionId,operationId:e.operationId}:{},displayOptions:{...a.displayOptions}},persistExplorerState:a.persistExplorerState,includeCookies:e.includeCookies,runtime:t,runTelemetry:a.runTelemetry,allowDynamicStyles:!1};return`
<div class="fallback">
  <h1>Welcome to Apollo Server</h1>
  <p>Apollo Explorer cannot be loaded; it appears that you might be offline.</p>
</div>
<style nonce=${o}>
  iframe {
    background-color: white;
    height: 100%;
    width: 100%;
    border: none;
  }
  #embeddableExplorer {
    width: 100vw;
    height: 100vh;
    position: absolute;
    top: 0;
  }
</style>
<div id="embeddableExplorer"></div>
<script nonce="${o}" src="https://embeddable-explorer.cdn.apollographql.com/${encodeURIComponent(n)}/embeddable-explorer.umd.production.min.js?runtime=${encodeURIComponent(t)}"><\/script>
<script nonce="${o}">
  var endpointUrl = window.location.href;
  var embeddedExplorerConfig = ${d(i)};
  new window.EmbeddedExplorer({
    ...embeddedExplorerConfig,
    endpointUrl,
  });
<\/script>
`},u=(n,e,t,o)=>{const a={runTelemetry:!0,endpointIsEditable:!1,initialState:{},...typeof e.embed=="boolean"?{}:e.embed??{}},i={target:"#embeddableSandbox",initialState:{..."document"in e||"headers"in e||"variables"in e?{document:e.document,variables:e.variables,headers:e.headers}:{},..."collectionId"in e?{collectionId:e.collectionId,operationId:e.operationId}:{},includeCookies:e.includeCookies,...a.initialState},hideCookieToggle:!1,endpointIsEditable:a.endpointIsEditable,runtime:t,runTelemetry:a.runTelemetry,allowDynamicStyles:!1};return`
<div class="fallback">
  <h1>Welcome to Apollo Server</h1>
  <p>Apollo Sandbox cannot be loaded; it appears that you might be offline.</p>
</div>
<style nonce=${o}>
  iframe {
    background-color: white;
    height: 100%;
    width: 100%;
    border: none;
  }
  #embeddableSandbox {
    width: 100vw;
    height: 100vh;
    position: absolute;
    top: 0;
  }
</style>
<div id="embeddableSandbox"></div>
<script nonce="${o}" src="https://embeddable-sandbox.cdn.apollographql.com/${encodeURIComponent(n)}/embeddable-sandbox.umd.production.min.js?runtime=${encodeURIComponent(t)}"><\/script>
<script nonce="${o}">
  var initialEndpoint = window.location.href;
  var embeddedSandboxConfig = ${d(i)};
  new window.EmbeddedSandbox(
    {
      ...embeddedSandboxConfig,
      initialEndpoint,
    }
  );
<\/script>
`};var g=r(8357),v=r(8604),f=r(13);function y(n={}){const{version:e,__internal_apolloStudioEnv__:t,...o}={embed:!0,...n};return m(e,{isProd:!1,apolloStudioEnv:t,...o})}function S(n={}){const{version:e,__internal_apolloStudioEnv__:t,...o}=n;return m(e,{isProd:!0,apolloStudioEnv:t,...o})}function x(n){return JSON.stringify(encodeURIComponent(JSON.stringify(n)))}const c=(n,e,t,o)=>`
 <div class="fallback">
  <h1>Welcome to Apollo Server</h1>
  <p>The full landing page cannot be loaded; it appears that you might be offline.</p>
</div>
<script>window.landingPage = ${x(e)};<\/script>
<script nonce="${o}" src="https://apollo-server-landing-page.cdn.apollographql.com/${encodeURIComponent(n)}/static/js/main.js?runtime=${t}"><\/script>`;function m(n,e){const t=n??"_latest",o=`@apollo/server@${g.b}`,a=["https://apollo-server-landing-page.cdn.apollographql.com","https://embeddable-sandbox.cdn.apollographql.com","https://embeddable-explorer.cdn.apollographql.com"].join(" "),i=["https://apollo-server-landing-page.cdn.apollographql.com","https://embeddable-sandbox.cdn.apollographql.com","https://embeddable-explorer.cdn.apollographql.com","https://fonts.googleapis.com"].join(" "),C=["https://explorer.embed.apollographql.com","https://sandbox.embed.apollographql.com","https://embed.apollo.local:3000"].join(" ");return{__internal_installed_implicitly__:!1,async serverWillStart($){return e.precomputedNonce&&$.logger.warn("The `precomputedNonce` landing page configuration option is deprecated. Removing this option is strictly an improvement to Apollo Server's landing page Content Security Policy (CSP) implementation for preventing XSS attacks."),{async renderLandingPage(){const p=encodeURIComponent(t);async function w(){const l=e.precomputedNonce??(0,v.createHash)("sha256").update((0,f.Z)()).digest("hex"),E=`script-src 'self' 'nonce-${l}' ${a}`,P=`style-src 'nonce-${l}' ${i}`,I="img-src https://apollo-server-landing-page.cdn.apollographql.com",k="manifest-src https://apollo-server-landing-page.cdn.apollographql.com",_=`frame-src ${C}`;return`
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="Content-Security-Policy" content="${E}; ${P}; ${I}; ${k}; ${_}" />
    <link
      rel="icon"
      href="https://apollo-server-landing-page.cdn.apollographql.com/${p}/assets/favicon.png"
    />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap"
      rel="stylesheet"
    />
    <meta name="theme-color" content="#000000" />
    <meta name="description" content="Apollo server landing page" />
    <link
      rel="apple-touch-icon"
      href="https://apollo-server-landing-page.cdn.apollographql.com/${p}/assets/favicon.png"
    />
    <link
      rel="manifest"
      href="https://apollo-server-landing-page.cdn.apollographql.com/${p}/manifest.json"
    />
    <title>Apollo Server</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="react-root">
      <style nonce=${l}>
        body {
          margin: 0;
          overflow-x: hidden;
          overflow-y: hidden;
        }
        .fallback {
          opacity: 0;
          animation: fadeIn 1s 1s;
          animation-iteration-count: 1;
          animation-fill-mode: forwards;
          padding: 1em;
        }
        @keyframes fadeIn {
          0% {opacity:0;}
          100% {opacity:1; }
        }
      </style>
    ${e.embed?"graphRef"in e&&e.graphRef?b(t,e,o,l):"graphRef"in e?c(t,e,o,l):u(t,e,o,l):c(t,e,o,l)}
    </div>
  </body>
</html>
          `}return{html:w}}}}}}}};

//# sourceMappingURL=208.js.map