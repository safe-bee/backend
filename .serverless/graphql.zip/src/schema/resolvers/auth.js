import { signUpToCognito, authenticaToCognito, forgotPasswordToCognito, confirmPasswordToCognito, } from "../../services/auth";
import { CognitoErrors } from "../types/auth";
const authResolvers = {
    Query: {},
    Mutation: {
        signUp: async (_parent, args, context) => {
            const user = args.input;
            let payload;
            const cognitoRes = await signUpToCognito(user);
            if (cognitoRes.error) {
                if (cognitoRes.error.name === CognitoErrors.USER_EXISTS) {
                    payload = {
                        user: null,
                        error: { field: "username", reason: "USERNAME_EXISTS" },
                    };
                }
                if (cognitoRes.error.name === CognitoErrors.INVALID_PASSWORD) {
                    payload = {
                        user: null,
                        error: { field: "password", reason: "INVALID_PASSWORD_POLICY" },
                    };
                }
            }
            else {
                payload = {
                    user: {
                        username: user.username,
                        userId: Math.random().toString(),
                    },
                    error: null,
                };
            }
            return payload;
        },
        signIn: async (_parent, args) => {
            const user = args.input;
            // const userModel = context.models.user;
            let payload;
            const cognitoRes = await authenticaToCognito(user);
            if (cognitoRes.error) {
                if (cognitoRes.error.name === CognitoErrors.INVALID_CREDENTIALS) {
                    payload = {
                        user: null,
                        error: {
                            field: "username || password",
                            reason: "NOT_AUTHORIZED",
                        },
                    };
                }
                if (cognitoRes.error.name === CognitoErrors.USER_NOT_CONFIRMED) {
                    payload = {
                        user: null,
                        error: {
                            field: "username",
                            reason: "USER_NOT_CONFIRMED",
                        },
                    };
                }
            }
            else {
                payload = {
                    user: {
                        username: cognitoRes.user.username,
                        userId: cognitoRes.user.cognitoUsername,
                    },
                    error: null,
                };
            }
            return payload;
        },
        forgotPassword: async (_parent, args) => {
            const user = args.input;
            let payload;
            const cognitoRes = await forgotPasswordToCognito(user.username);
            if (cognitoRes.error) {
                payload = {
                    emailSent: false,
                    error: {
                        field: "none",
                        reason: "EMAIL_ISSUE",
                    },
                };
            }
            else {
                payload = {
                    emailSent: cognitoRes.user.emailSent,
                    error: null,
                };
            }
            return payload;
        },
        confirmNewPassword: async (_parent, args) => {
            const user = args.input;
            let payload;
            const cognitoRes = await confirmPasswordToCognito(user);
            if (cognitoRes.error) {
                if (cognitoRes.error.name === CognitoErrors.EXPIRTED_CODE_EXCEPTION) {
                    payload = {
                        operation: cognitoRes.operation,
                        error: {
                            field: "code",
                            reason: "CODE_EXPIRED",
                        },
                    };
                }
                else if (cognitoRes.error.name === CognitoErrors.INVALID_CODE_PROVIDED) {
                    payload = {
                        operation: cognitoRes.operation,
                        error: {
                            field: "code",
                            reason: "INVALID_CODE",
                        },
                    };
                }
                else if (cognitoRes.error.name === CognitoErrors.LIMITED_EXCEED) {
                    payload = {
                        operation: cognitoRes.operation,
                        error: {
                            field: "api",
                            reason: "LIMIT_EXCEED",
                        },
                    };
                }
                else if (cognitoRes.error.name === CognitoErrors.INVALID_PASSWORD) {
                    payload = {
                        operation: cognitoRes.operation,
                        error: {
                            field: "api",
                            reason: "INVALID_PASSWORD_POLICY",
                        },
                    };
                }
            }
            else {
                payload = {
                    operation: cognitoRes.operation,
                    error: null,
                };
            }
            return payload;
        },
    },
};
export default authResolvers;
