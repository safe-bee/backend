var CognitoErrors;
(function (CognitoErrors) {
    CognitoErrors["USER_EXISTS"] = "UsernameExistsException";
    CognitoErrors["INVALID_PASSWORD"] = "InvalidPasswordException";
    CognitoErrors["INVALID_CREDENTIALS"] = "NotAuthorizedException";
    CognitoErrors["USER_NOT_CONFIRMED"] = "UserNotConfirmedException";
    CognitoErrors["EXPIRTED_CODE_EXCEPTION"] = "ExpiredCodeException";
    CognitoErrors["INVALID_CODE_PROVIDED"] = "CodeMismatchException";
    CognitoErrors["LIMITED_EXCEED"] = "LimitExceededException";
})(CognitoErrors || (CognitoErrors = {}));
var CognitoOperationResult;
(function (CognitoOperationResult) {
    CognitoOperationResult["OPERATION_SUCCESS"] = "SUCCESS";
    CognitoOperationResult["OPERATION_FAILED"] = "FAILED";
})(CognitoOperationResult || (CognitoOperationResult = {}));
export { CognitoErrors, CognitoOperationResult };
